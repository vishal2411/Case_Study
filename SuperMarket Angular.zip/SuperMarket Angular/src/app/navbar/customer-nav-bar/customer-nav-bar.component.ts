import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-nav-bar',
  templateUrl: './customer-nav-bar.component.html',
  styleUrls: ['./customer-nav-bar.component.css']
})
export class CustomerNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
