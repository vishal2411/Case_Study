import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-outer-nav-bar',
  templateUrl: './seller-outer-nav-bar.component.html',
  styleUrls: ['./seller-outer-nav-bar.component.css']
})
export class SellerOuterNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
