export class Payment{
    
    // declare properties
    paymentId: number;
    paymentMethod: string;
    totalPrice : number;
    prodId : number;
    custId : number;
    sellerId : number;
}