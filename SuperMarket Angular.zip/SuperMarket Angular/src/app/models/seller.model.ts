export class Seller
{
    // declare properties
    sellerId : number;
    sellerName : string;
    sellerMobile: string;
    sellerEmail: string;
    sellerCategory: string;
    sellerAddress: string;
    sellerPassword: string;
    sellerConfPass: string;
}

export class sellerVM{
    sellerId: number;
    sellerEmail: string;
    sellerPassword: string;
  }

