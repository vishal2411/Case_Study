export class Customer{

    // declare properties
    custId : number;
    custName : string;
    gender: string;
    custAddress: string;
    custEmail: string;
    custMobile: number;
    custPassword: string;
    custConfPass: string;
}

export class customerVM{
    custId: number;
    custEmail: string;
    custPassword: string;
  }
