export class Product{

    // declare properties
    prodId : number;
    prodName : string;
    prodDesc: string;
    prodImage: string;
    prodCategory: string;
    prodPrice: number;
    prodDiscount: number;
    prodStatus: string;
    sellerId: number
}