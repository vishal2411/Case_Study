export class Cart{

    // declare properties
    cartId: number;
    prodId: number;
    custId: number;
}
