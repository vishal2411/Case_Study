export class Order{
    
    //declare properties
    orderId: number;
    orderStatus : string;
    orderDate : Date;
    prodId : number;
    custId : number;
    paymentId : number;
    sellerId : number;
}