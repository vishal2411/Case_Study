import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-my-order',
  templateUrl: './customer-my-order.component.html',
  styleUrls: ['./customer-my-order.component.css']
})
export class CustomerMyOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
